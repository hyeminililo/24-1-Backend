package net.skhu.dto;

import lombok.Data;

@Data
public class Genre {

	int id;
	String title;
	
	
}
