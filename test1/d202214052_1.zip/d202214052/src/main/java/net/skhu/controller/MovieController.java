package net.skhu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import net.skhu.dto.Genre;
import net.skhu.dto.Movie;
import net.skhu.mapper.GenreMapper;
import net.skhu.mapper.MovieMapper;

@Controller
@RequestMapping("movie")
public class MovieController {
    @Autowired
    MovieMapper movieMapper;

    @Autowired
    GenreMapper genreMapper;

    // 학생 목록 페이지로 이동
    @GetMapping("list")
    public String list(Model model) {
        List<Movie> movies = movieMapper.findAll();
        model.addAttribute("movies", movies);
        return "movie/list";
    }

    // 학생 생성 페이지로 이동
    @GetMapping("create")
    public String create(Model model) { 
        Movie movie = new Movie(); // 빈 학생 객체 생성
        List<Genre> genres = genreMapper.findAll(); // 모든 학과 정보 가져오기
        model.addAttribute("movie", movie);
        model.addAttribute("genres", genres);
        return "movie/edit"; // 학생 생성/수정 페이지 사용
    }

    // 학생 생성 처리
    @PostMapping("create")
    public String create(Model model, Movie movie) {
        movieMapper.insert(movie);
        return "redirect:list"; // 학생 목록 페이지로 리다이렉트
    }

    // 학생 수정 페이지로 이동
    @GetMapping("edit")
    public String edit(Model model, int id) {
        Movie movie = movieMapper.findOne(id); // 수정할 학생 정보 가져오기
        List<Genre> genres = genreMapper.findAll(); // 모든 학과 정보 가져오기
        model.addAttribute("movie", movie);
        model.addAttribute("genres", genres);
        return "movie/edit"; // 학생 생성/수정 페이지 사용
    }

    // 학생 수정 처리
    @PostMapping("edit")
    public String edit(Model model, Movie movie) {
        movieMapper.update(movie);
        return "redirect:list"; // 학생 목록 페이지로 리다이렉트
    }

    // 학생 삭제 처리
    @GetMapping("delete")
    public String delete(Model model, int id) {
        movieMapper.delete(id);
        return "redirect:list"; // 학생 목록 페이지로 리다이렉트
    }
}
